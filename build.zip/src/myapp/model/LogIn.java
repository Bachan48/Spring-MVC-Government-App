package myapp.model;

public class LogIn {

}
