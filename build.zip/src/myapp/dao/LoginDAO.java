package myapp.dao;

public class LoginDAO {

}
