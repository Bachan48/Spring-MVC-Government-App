package myapp.dao;

public class LoginDAOImpl {

}
